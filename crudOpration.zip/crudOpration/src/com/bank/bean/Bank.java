package com.bank.bean;

public class Bank {

}
