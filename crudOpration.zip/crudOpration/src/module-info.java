/**
 * 
 */
/**
 * @author admin
 *
 */
module crudOpration {
	requires java.sql;
}